import Home from '@/view/home/home'
import About from '@/view/about/about'

const routes = [
    {path: '/home', component: Home},
    {path: '/about', component: About},

];
export {routes}

