const setCollapse = data => {
  return {
    type: 'setCollapse',
    data
  }
};

export { setCollapse }
