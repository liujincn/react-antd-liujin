import React from 'react';

class Home extends React.Component {

  render () {
    return (
      <div>首页</div>
    );
  }
}

export default Home
