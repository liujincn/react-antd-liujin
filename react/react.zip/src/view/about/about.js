import React, { Component } from 'react';

class About extends Component {

  render () {
    return (
      <div>关于</div>
    );
  }
}

export default About
